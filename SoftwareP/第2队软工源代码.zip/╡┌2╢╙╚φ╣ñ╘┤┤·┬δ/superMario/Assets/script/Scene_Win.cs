﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Scene_Win : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnGUI()
    {
        var groundWidth = 120;
        var groundHeight = 150;
        var screenWidth = Screen.width;
        var screenHeight = Screen.height;
        var groupx = (screenWidth - groundWidth) / 2;
        var groupy = (screenHeight - groundHeight) / 2;

        //GUI.Box(new Rect(groupx, groupy, groundWidth, groundHeight), "Super Mario");

        //GUI.TextField(new Rect(groupx, groupy-10, groundWidth, groundHeight), GetComponent<MarioCtrl>().GetingScore());



        if (GUI.Button(new Rect(50, screenHeight - 100, 100, 30), "ReStart"))

        {
            SceneManager.LoadScene("level1");

        }

        if (GUI.Button(new Rect(screenWidth/2-50, screenHeight - 100, 100, 30), "BackMemu"))

        {
            SceneManager.LoadScene("Memu");

        }

        if (GUI.Button(new Rect(screenWidth - 150, screenHeight - 100, 100, 30), "Quit"))

        {
            Application.Quit();

        }

    }
}
