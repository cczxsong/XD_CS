﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Scene_About : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnGUI()
    {
        var groundWidth = 300;
        var groundHeight = 120;
        var screenWidth = Screen.width;
        var screenHeight = Screen.height;
        var groupx = (screenWidth - groundWidth) / 2;
        var groupy = (screenHeight - groundHeight) / 2;

        GUI.BeginGroup(new Rect(groupx, groupy, groundWidth, groundHeight));
        GUI.Box(new Rect(0, 0, groundWidth, groundHeight), "Super Mario");
        GUI.Label(new Rect(20, 20, 250, 20), "版        本: 1.0");

        GUI.Label(new Rect(20, 50, 300, 20), "开  发  者:Sylvester,JackZ,Garfield,DJ,ZX,CHR");

        GUI.Label(new Rect(20, 80, 250, 20), "联系我们 :cczxsong@163.com");
        
        GUI.EndGroup();
        if (GUI.Button(new Rect(50, screenHeight - 100, 100, 30), "back"))

        {
            SceneManager.LoadScene("Memu");

        }
        if (GUI.Button(new Rect(screenWidth - 150, screenHeight - 100, 100, 30), "Quit"))

        {
            Application.Quit();

        }
    }

}
