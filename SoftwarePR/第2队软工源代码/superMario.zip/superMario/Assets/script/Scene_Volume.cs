﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Scene_Volume : MonoBehaviour
{
    private float masterVolume = 1.0f;
    private float sfxVolume = 1.0f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void OnGUI()
    {
        var groupWidth = 380;
        var groupHeight = 110;
        var screenWidth = Screen.width;
        var screenHeight = Screen.height;
        var groupX = (screenWidth - groupWidth) / 2;
        var groupY = (screenHeight - groupHeight) / 2;

        GUI.BeginGroup(new Rect(groupX, groupY, groupWidth, groupHeight));
        GUI.Box(new Rect(0, 0, groupWidth, groupHeight), "Audio Settings");
        GUI.Label(new Rect(10, 30, 100, 30), "Master Volume");
        masterVolume = GUI.HorizontalSlider(new Rect(120, 35, 200, 30), masterVolume, 0.0f, 1.0f);
        GUI.Label(new Rect(330, 30, 50, 30), "(" + (masterVolume*100).ToString("f2") + ")");


        GUI.Label(new Rect(10, 70, 100, 30), "Effect Volume");
        sfxVolume = GUI.HorizontalSlider(new Rect(120, 75, 200, 30), sfxVolume, 0.0f, 1.0f);
        GUI.Label(new Rect(330, 70, 50, 30), "(" + (sfxVolume*100).ToString("f2") + ")");
        GUI.EndGroup();

        if (GUI.Button(new Rect(50, screenHeight-100, 100, 30), "back"))

        {
            SceneManager.LoadScene("Memu");

        }
        if (GUI.Button(new Rect(screenWidth-150, screenHeight - 100, 100, 30), "Quit"))

        {
            Application.Quit();

        }
    }

}
