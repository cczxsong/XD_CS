﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Scene_Memu: MonoBehaviour
{
    

    // Start is called before the first frame update
    void Start()
    {

       
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnGUI()
    {
        var groundWidth = 120;
        var groundHeight = 190;
        var screenWidth = Screen.width;
        var screenHeight = Screen.height;
        var groupx = (screenWidth - groundWidth) / 2;
        var groupy = (screenHeight - groundHeight) / 2;

        GUI.BeginGroup(new Rect(groupx, groupy, groundWidth, groundHeight));
        GUI.Box(new Rect(0, 0, groundWidth, groundHeight), "Super Mario");
        if (GUI.Button(new Rect(10, 30, 100, 30), "LevelSelect"))
        {
            //Application.LoadLevel(1);
            SceneManager.LoadScene("LevelSelect");
        }

        if (GUI.Button(new Rect(10, 70, 100, 30), "Volume"))
            
        {
            //Application.LoadLevel(2);
            SceneManager.LoadScene("Volume");
            
        }
        if (GUI.Button(new Rect(10, 110, 100, 30), "About"))
        {
            //Application.LoadLevel(3);
            SceneManager.LoadScene("About");

        }
        if (GUI.Button(new Rect(10, 150, 100, 30), "Quit"))
        {
            //Application.LoadLevel(3);
            //SceneManager.LoadScene(3);
            Application.Quit();

        }
        

        GUI.EndGroup();
    }
}
