﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Scene_Login : MonoBehaviour
{
    private string userName;//用户名
    private string userPassword;//密码
    private string info;//信息
    // Start is called before the first frame update
    void Start()
    {
        //初始化
        userName = "";
        userPassword = "";
        info = "";
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnGUI()
    {
        var screenWidth = Screen.width;
        var screenHeight = Screen.height;
        //用户名
        GUI.Label(new Rect(20, 20, 50, 20), "username");
        userName = GUI.TextField(new Rect(80, 20, 100, 20), userName, 15);//15为最大字符串长度
                                                                          //密码
        GUI.Label(new Rect(20, 50, 50, 20), "password");
        userPassword = GUI.PasswordField(new Rect(80, 50, 100, 20), userPassword, '*');//'*'为密码遮罩
                                                                                       //信息
        GUI.Label(new Rect(20, 100, 100, 20), info);
        //登录按钮
        if (GUI.Button(new Rect(80, 80, 45, 20), "Login"))
        {
            if (userName == "admin" && userPassword == "admin")
            {
                //info = "登录成功！";
                SceneManager.LoadScene("Memu");
            }
            else
            {
                info = "login failed！";
            }
        }
        if (GUI.Button(new Rect(135, 80, 45, 20), "Quit"))

        {
            Application.Quit();

        }
    }
}


